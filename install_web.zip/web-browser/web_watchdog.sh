#!/bin/bash

# Script by mcobit

# give Aurora time to start up
sleep 60

# Checking if Aurora is running, if not start mediacenter again
while [ true ]; do
        VAR1="$(pgrep arora)"
                if [ ! "$VAR1" ]; then
                        sudo openvt -c 7 -s -f clear
                        sudo su -c "sudo systemctl start mediacenter &" &
                        exit
                else
                        sleep 5
                fi
done
exit

