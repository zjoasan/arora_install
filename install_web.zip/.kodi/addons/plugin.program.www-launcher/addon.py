"""
    Plugin for Launching programs
"""

# -*- coding: UTF-8 -*-
# main imports
import sys
import os
import xbmc
import xbmcgui
import xbmcaddon

# plugin constants
__plugin__ = "www-launcher"
__author__ = "jcnventura"
__url__ = "http://blog.petrockblock.com/retropie/"
__git_url__ = "https://github.com/mcobit/retrosmc/"
__credits__ = "mcobit"
__version__ = "0.0.2"

dialog = xbmcgui.Dialog()
addon = xbmcaddon.Addon(id='plugin.program.www-launcher')

output=os.popen("/home/osmc/web-browser/webstart2.sh").read()
#dialog.ok("Starting Arora",output)
#print output
