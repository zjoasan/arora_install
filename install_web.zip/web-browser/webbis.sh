#!/bin/bash
sleep 30
sudo su root -c "nohup openvt -c 7 -f -s fbi /home/osmc/web-browser/fanart.jpg &" &
sleep 10
sudo pkill -9 fbi
sudo su root -c "fbset -xres 1280"
sudo su root -c "fbset -yres 1024"
sudo su root -c "fbset -vxres 1280"
sudo su root -c "fbset -vyres 1024"
sudo arora -platform "linuxfb" -plugin EvdevMouse -plugin "EvdevKeyboard:grab=1" www.google.se 
exit

